

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Crud with image Mysqli</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="Bootstrap-4-4.6.0/css/bootstrap.css">
  <link rel="stylesheet" href="Bootstrap-4-4.6.0/css/dataTables.bootstrap4.min.css">
  
<script src="Bootstrap-4-4.6.0/js/jquery-3.3.1.min.js"></script>
<script src="Bootstrap-4-4.6.0/js/bootstrap.js"></script>
<script src="Bootstrap-4-4.6.0/js/jquery.dataTables.min.js"></script>
<script src="Bootstrap-4-4.6.0/js/dataTables.bootstrap4.min.js"></script>

</head>
<style>
  .alert-success{
    display:none;
    width:40%;
    margin-left:70px;
    /* margin:auto; */
  }

  .alert-danger{
    width:70%;
     margin:auto;
     display:none;
    
  }
  </style>
<body>


<div class="container">

    <div class="rwo">

   
      
  <h2 class="mt-4 text-primary text-center">Crud with image Mysqli</h2>
  <button type="button" class="btn btn-primary btn-sm float-right" data-toggle="modal" data-target="#CreateModal">
  Record Add
</button>
  

     <!-- start  insert form -->
 <div class="modal fade modalhide" id="CreateModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Record Insert</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!-- <div class="text-center" id="error-message"></div>  -->
        <div class="alert alert-danger mt-2" id="error-message"> </div> 
    
 
        <!-- Modal body -->
        <div class="modal-body">
        <form id="insertform">

<div class="form-group">
  <label for="Student">Student:</label>
  <input type="text" class="form-control" id="" placeholder="Enter Student Name" name="stud_name"required>
</div>

<div class="form-group">
  <label for="Student">Student Class:</label>
  <input type="text" class="form-control" id="" placeholder="Enter Student Class" name="stud_class"required>
</div>

<div class="form-group">
  <label for="Student">Student Phone:</label>
  <input type="text" class="form-control" id="" placeholder="Enter Student phone No" name="stud_phone"required>
</div>

<div class="form-group">
  <label for="Student">Student Image:</label>
  <input type="file" class="form-control-file border"name="stud_image"required>
</div>
<input type="Submit" name="save_stud_image"value="Submit"class="btn btn-success form-control subg"id="sub">

</form>
        </div>
        
   
    
      </div>
    </div>
  </div>
  
           <!-- start update form -->
  


<!-- <div class="alert1" id="success-message"></div>  -->
<div class="alert alert-success" id="success-message">
    
  </div>               
           
<div class="modal fade" id="UpdateModal">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title">Update Image</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <form action="" id="Updateform">
                    
                        <div id="edit-image"></div>
                        
                    <!-- Modal footer -->
                    <div class="modal-footer">
                      
                        <button type="submit" class="btn btn-success " name="update_stud_image" id="save_stud_image">Update</button>
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    </div>
                </form>


            </div>
        </div>
    </div>

       <!-- Start All data Fetch table -->

    <div id="table-data"></div>

     <!-- End All data Fetch table -->

    </div>
    </div>


        </div>



        
    </div>

 
</div>

  <script>
     
        $(document).ready(function(){

 
        function loadTable(){
           $.ajax({
            url:"display.php",
            type:"POST",
            success: function(data){
            $("#table-data").html(data);

            $("table").DataTable({
              order: [0, 'dec']
            });
            
            }
           });

          }
           loadTable(); //ajax page table load
           


              // start insert form code
         $("#insertform").on("submit", function(e){

        function message(message, status){
            if(status == true){
            $("#success-message").html(message).slideDown();
            $("#error-message").fadeOut();
            setTimeout(function(){
            $("#success-message").fadeOut();
            },3000);

            }else if(status == false){
            $("#error-message").html(message).slideDown();
           $("#success-message").fadeOut();
           setTimeout(function(){
           $("#error-message").fadeOut();
           },3000);
          }
        }
               e.preventDefault();


         $.ajax({
         url :"insert.php",
         type : "POST",
         data: new FormData(this),
         dataType:"json",
         contentType : false,
         processData : false,
         success: function(data){ 
            
            loadTable();
            message(data.message, data.status);

            if(data.status == true){
        $('.modal').modal('hide');
        $("#insertform").trigger("reset");
        $(".form-control-file").empty(); 
      
               }
          
            }
          });

          });
            // End insert form code

          
    
            //  start load update form code

        $(document).on("click", '.edit-btn', function () {
          var stud_id = $(this).closest("tr").find('.stud_id').text();

        $.ajax({
            url: "loadupdateform.php",
            type: "POST",
            data: { id: stud_id },
            success: function(data){
                $("#edit-image").html(data);
            }
        })
    });
              //  End load update form code

             
               $("#Updateform").on('submit',function(e){

                    function message(message, status){
                       if(status == true){
                    $("#success-message").html(message).slideDown();
                    $("#error-message").fadeOut();
                    setTimeout(function(){
                      $("#success-message").fadeOut();
                    },2000);

                       }else if(status == false){
                      $("#error-message").html(message).slideDown();
                      $("#success-message").fadeOut();
                      setTimeout(function(){
                      $("#error-message").fadeOut();
                     },2000);
                       }
                     }
                e.preventDefault();
                    
                        const formData = new FormData(this);
                           
                       $.ajax({
                        url:"updateform.php",
                       type: "POST",
                       data: formData,
                       dataType:"json",
                       processData: false,
                       contentType: false,
                      
                          success:function(data){
                            loadTable();
                            message(data.message, data.status);

                            if(data.status == true){
                            $("#UpdateModal").modal("hide");

                            }
                          }

                          
                    });
               });
           

                    //  Start Delete code
                    $(document).on( "click",'#delete-image',function(e){
                      const id = $(this).data("id");
                      // var stud_id = $(this).closest("tr").find('.stud_id_delete').text();
                      // const formData = new FormData(this);
                      function message(message, status){
                       if(status == true){
                    $("#success-message").html(message).slideDown();
                    $("#error-message").fadeOut();
                    setTimeout(function(){
                      $("#success-message").fadeOut();
                    },2000);

                       }else if(status == false){
                      $("#error-message").html(message).slideDown();
                      $("#success-message").fadeOut();
                      setTimeout(function(){
                      $("#error-message").fadeOut();
                     },2000);
                       }
                     }
                      e.preventDefault();
                      $.ajax({
                        url:"delete.php",
                        type: "POST",
                        dataType:"json",
                        data: { id: id },
                     
            
                          success:function(data){
                          
                            loadTable();
                            message(data.message, data.status);

                            if(data.status == true){
                           

                            }
                          }

                          
                    });
                    });
                    //  End Delete code
      

              });

</script>
</body>
</html>