
<?php
$con = mysqli_connect('localhost','root','','phpmysqlicrud');

// if(isset($_POST['delete_stud_image_btn'])){

//   $id= $_POST['delete_id'];// input field hidden id
//   $stud_image= $_POST['delete_stud_image']; // input field hidden image

//   $query = "DELETE FROM  phpimgcrud WHERE id = '$id'";
//    $query_run = mysqli_query($con,$query);

//    if($query_run){
//      unlink('upload/'.$stud_image);
//     $_SESSION['status'] = 'Data Delete Successfully';
//     header('location:index.php');
//    }

//     else{
//       $_SESSION['status'] = 'Data Not Successfully';
//       header('location:index.php');
//     }


  $id= $_POST['id'];// input field hidden id
 
  $sql="SELECT * FROM phpimgcrud WHERE id='{$id}'";

  $run_sql=mysqli_query($con,$sql);
  $result=mysqli_fetch_assoc($run_sql);

  unlink("upload/".$result["stud_image"]);
    
    $sql1="DELETE FROM phpimgcrud WHERE id='{$id}'";
    $run_sql1=mysqli_query($con,$sql1);
    if($run_sql1){
      echo json_encode(array('message' => '<h6> Record Deleted Successufully</h6>', 'status' => true));

        // echo json_encode(array('message' => '<h6> Record Deleted Successufully</h6>', 'status' => true ));
    }else{
      echo json_encode(array('message' => '<h6> Record Not Deleted </h6>', 'status' => false ));
    }
  
?>