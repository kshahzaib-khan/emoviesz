<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Name</th>
                <th>Position</th>
                <th>Office</th>
                <th>Age</th>
                <th>Start date</th>
                <th>Salary</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger Nixon</td>
                <td>System Architect</td>
                <td>Edinburgh</td>
                <td>61</td>
                <td>2011/04/25</td>
                <td>$320,800</td>
           
</tr>
               
           
        </tbody>
       
    </table>
  </div>



  <?php
$con = mysqli_connect('localhost','root','','phpmysqlicrud');
$q="select * from phpimgcrud ORDER BY id DESC limit 0,6";
$run=mysqli_query($con,$q);     
 while($row=mysqli_fetch_array($run))


{
   $id=$row['id'];
   $name=$row['name'];
   $img=$row['img']; 
    $brand=$row['brand'];                                       

?> 



<div class="col-sm-4">
<center><?php echo"<img src='admin/c/$img'width='90px'height='165px'>"?></center>


 <h6 align="center"><?php echo $name;?></h6> 
 <h4 align="center"><?php echo $brand;?></h4> 
 <center><a href="b.php?id=<?php echo $id;?>" class="btn btn-danger btn-xs" style="margin-bottom: 15px;">Buy Now</a></center> 
       
 

</div>

<?php

}  
?>