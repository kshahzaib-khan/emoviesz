<?php
session_start();
$con = mysqli_connect('localhost','root','','phpmysqlicrud');
 
if(isset($_POST['save_stud_image'])){

    $stud_name = $_POST['stud_name'];
    $stud_class = $_POST['stud_class'];
    $stud_phone = $_POST['stud_phone'];

    $image = $_FILES['stud_image']['name'];

      $allowed_exttension = array('gif','png','jpg','jpeg');
      $filename = $_FILES['stud_image']['name'];
      $file_extention = pathinfo($filename, PATHINFO_EXTENSION);
        if(!in_array($file_extention, $allowed_exttension)){
            $_SESSION['status'] = 'You are allowed with only jpg png jpeg and gif';
            header('location:create.php');
        }
         else{
              
         

      if(file_exists("upload/".$_FILES['stud_image']['name'])){
         $filename = $_FILES['stud_image']['name'];
        $_SESSION['status'] = 'Image already Exists  '.$filename;
        header('location:index.php');
      }

     else{

       
    $query = "INSERT INTO phpimgcrud(stud_name,stud_class,stud_phone,stud_image)
    VALUES('$stud_name','$stud_class','$stud_phone','$image')";

    $query_run = mysqli_query($con,$query);

    if($query_run){
        move_uploaded_file($_FILES["stud_image"]["tmp_name"], "upload/".$_FILES["stud_image"]["name"]);
      $_SESSION['status'] = 'Image Store Successfully';
        header('location:index.php');
    }
    else{
           
        $_SESSION['status'] = 'Image not Inserted';
        header('location:index.php');
    }

}

}


}


            // Start Update Code

  if(isset($_POST['update_stud_image']))
   {
       $stud_id = $_POST['stud_id']; // input field hidden id
       $name = $_POST['stud_name'];
       $class = $_POST['stud_class'];
       $phone = $_POST['stud_phone'];

  
       $new_image = $_FILES['stud_image']['name'];
       $stud_image_old = $_POST['stud_image_old'];

       if($new_image != ''){
           
          $update_filename = $_FILES['stud_image']['name'];

       }
       else{
    
            $update_filename = $stud_image_old;
       }

       if($_FILES['stud_image']['name'] != '')
       {
     
       if(file_exists('upload/' . $_FILES['stud_image']['name'])){
        $filename = $_FILES['stud_image']['name'];
       $_SESSION['status'] = 'Image already Exists'.$filename;
       header('location:index.php');
     }
     }

    else{
          $query = "UPDATE phpimgcrud SET stud_name='{$name}', stud_class='{$class}', stud_phone='{$phone}', stud_image= '{$update_filename}' WHERE id='{$stud_id}'";

          $query_run = mysqli_query($con,$query);
         
            if($query_run){

               if($_FILES['stud_image']['name'] !='')
               {
                move_uploaded_file($_FILES["stud_image"]["tmp_name"], "upload/".$_FILES["stud_image"]["name"]);
                  unlink('upload/'.$stud_image_old);
               }
              
              $_SESSION['status'] = 'Data Updated Successfully';
              header('location:index.php');
            }
             else{
              $_SESSION['status'] = 'Data Not Updated';
              header('location:index.php');
             }
    }

   }
                            // End Update Code





                    //Start Delete Code

           if(isset($_POST['delete_stud_image_btn'])){

            $id= $_POST['delete_id'];// input field hidden id
            $stud_image= $_POST['delete_stud_image']; // input field hidden image

            $query = "DELETE FROM  phpimgcrud WHERE id = '$id'";
             $query_run = mysqli_query($con,$query);

             if($query_run){
               unlink('upload/'.$stud_image);
              $_SESSION['status'] = 'Data Delete Successfully';
              header('location:index.php');
             }

              else{
                $_SESSION['status'] = 'Data Not Successfully';
                header('location:index.php');
              }
           }


               //End Delete Code



               

// if(isset($_POST['checkbox'][0])){
// 	foreach($_POST['checkbox'] as $list){
// 		$id=mysqli_real_escape_string($con,$list);
// 		mysqli_query($con,"delete from phpimgcrud where id='$id'");
// 	}
// }
?>