
<?php
$con = mysqli_connect('localhost','root','','phpmysqlicrud');



$stud_name = $_POST['stud_name'];
$stud_class = $_POST['stud_class'];
$stud_phone = $_POST['stud_phone'];

$image = $_FILES['stud_image']['name'];

  $allowed_exttension = array('gif','png','PNG','jpg','jpeg');
  $filename = $_FILES['stud_image']['name'];
  $file_extention = pathinfo($filename, PATHINFO_EXTENSION);
    if(!in_array($file_extention, $allowed_exttension)){
        echo json_encode(array('message' => '<h6>You are allowed with only jpg png jpeg and gif</h6>', 'status' => false));
        // $_SESSION['status'] = 'You are allowed with only jpg png jpeg and gif';
        // header('location:index.php');
    }
     else{
          
     

  if(file_exists("upload/".$_FILES['stud_image']['name'])){
     $filename = $_FILES['stud_image']['name'];

    // $_SESSION['status'] = 'Image already Exists  '.$filename;
    echo json_encode(array('message' => '<h6> Dublicate Image not Inserted</h6>'.$filename, 'status' => false ));
    // header('location:index.php');
  }

 else{

   
$query = "INSERT INTO phpimgcrud(stud_name,stud_class,stud_phone,stud_image)
VALUES('$stud_name','$stud_class','$stud_phone','$image')";

$query_run = mysqli_query($con,$query);

if($query_run){
    move_uploaded_file($_FILES["stud_image"]["tmp_name"], "upload/".$_FILES["stud_image"]["name"]);
//   $_SESSION['status'] = 'Image Store Successfully';
     echo json_encode(array('message' => '<h6>Your Record is Successfully saved</h6>', 'status' => true));
    // header('location:index.php');
}

else{
    echo json_encode(array('message' => '<h6> All Record not Inserted</h6>', 'status' => false));
  
}

}

}




?>