<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Crud with image Mysqli</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="Bootstrap-4-4.6.0/css/bootstrap.css">
  <link rel="stylesheet" href="Bootstrap-4-4.6.0/css/dataTables.bootstrap4.min.css">
</head>
<body>


<div class="container">
    <div class="rwo">
 
        <div class="col-lg-6 offset-lg-4">
  <h2 class="mt-4 text-primary">Crud with image Mysqli</h2>
    <?php
     if(isset($_SESSION['status']) && $_SESSION != ''){

        ?>
       
        <div class="alert alert-success alert-dismissible fade show">
    <button type="button" class="close" data-dismiss="alert">&times;</button>
    <strong>Success!</strong> <?php echo $_SESSION['status'];?>
  </div>
        <?php
          unset($_SESSION['status']);
     }
    ?>
  
  <form id="submit_form">

    <div class="form-group">
      <label for="Student">Student:</label>
      <input type="text" class="form-control" id="" placeholder="Enter Student Name" name="stud_name"required>
    </div>
   
    <div class="form-group">
      <label for="Student">Student Class:</label>
      <input type="text" class="form-control" id="" placeholder="Enter Student Class" name="stud_class"required>
    </div>

    <div class="form-group">
      <label for="Student">Student Phone:</label>
      <input type="text" class="form-control" id="" placeholder="Enter Student phone No" name="stud_phone"required>
    </div>

    <div class="form-group">
      <label for="Student">Student Image:</label>
      <input type="file" class="form-control-file border"name="stud_image"required>
    </div>

    <button type="submit" class="btn btn-primary"name="save_stud_image">Submit</button>
    <a href="index.php" class="btn btn-info">Home</a>
  </form>
 
  </div>
 
</div>

<script src="Bootstrap-4-4.6.0/js/jquery-3.3.1.min.js"></script>
<script src="Bootstrap-4-4.6.0/js/bootstrap.js"></script>
<script src="Bootstrap-4-4.6.0/js/jquery.dataTables.min.js"></script>
<script src="Bootstrap-4-4.6.0/js/dataTables.bootstrap4.min.js"></script>



  <!-- <script>
    
$(document).ready(function() {
    $('#example').DataTable();
} );
</script> -->
</body>
</html>