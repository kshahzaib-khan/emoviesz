
  <?php
  $id=$_POST['id'];
  $con = mysqli_connect('localhost','root','','phpmysqlicrud');
  $query = "SELECT * FROM phpimgcrud WHERE id ='$id'";
  $query_run = mysqli_query($con,$query);

  $output="";
  if(mysqli_num_rows(  $query_run) > 0){
      $output.="<div class='modal-body'>";
      while($row=mysqli_fetch_assoc( $query_run)){
            $stud_image = $row['stud_image'];
            
          $output .="
          
          <input type='hidden'name='stud_id'value='{$row["id"]}'='stud_id'>
          <div class='form-group'>
          <label for='Student'>Student:</label>
          <input type='text' class='form-control' id='stud_name' placeholder='Enter Student Name'name='stud_name' value='{$row["stud_name"]}'>
        </div>
       
        <div class='form-group'>
          <label for='Student'>Student Class:</label>
          <input type='text' class='form-control' id='stud_class' placeholder='Enter Student Class' name='stud_class' value='{$row["stud_class"]}'>
        </div>

        <div class='form-group'>
        <label for='Student'>Student Phone:</label>
        <input type='text' class='form-control' id='stud_phone' placeholder='Enter Student phone No' name='stud_phone' value='{$row["stud_phone"]}'>
      </div>
  
      <div class='form-group'>
        <label for='Student'>Student Image:</label>
        <input type='file' class='form-control-file border'name='stud_image'id='stud_image'>
        <input type='hidden' name='stud_image_old'value='{$row["stud_image"]}' id='stud_image_old'>

         </div>
         
            <span> <img src='upload/{$row["stud_image"]}'style='width:60px; height:60px;'></span>";
       

          
     
      }


      $output .="</div>";
      echo $output;
  }

         else{
               echo "Record not found ";
         }

  
   

    ?>
