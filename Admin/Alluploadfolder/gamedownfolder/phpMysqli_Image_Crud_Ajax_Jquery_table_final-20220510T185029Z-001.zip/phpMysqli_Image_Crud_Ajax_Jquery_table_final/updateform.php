<?php
// Start Update Code
$con = mysqli_connect('localhost','root','','phpmysqlicrud');


    $stud_id = $_POST['stud_id']; // input field hidden id
    $stud_name = $_POST['stud_name'];
    $stud_class = $_POST['stud_class'];
    $stud_phone = $_POST['stud_phone'];


    $new_image = $_FILES['stud_image']['name'];
    $stud_image_old = $_POST['stud_image_old'];

    if($new_image != ''){
        
       $update_filename = $_FILES['stud_image']['name'];

    }
    else{
 
         $update_filename = $stud_image_old;
    }

//     if($_FILES['stud_image']['name'] != '')
//     {
  
//     if(file_exists('upload/' . $_FILES['stud_image']['name'])){
//      $filename = $_FILES['stud_image']['name'];
//     $_SESSION['status'] = 'Image already Exists'.$filename;
 
//   }
//   }

//  else{
       $query = "UPDATE phpimgcrud SET stud_name='{$stud_name}', stud_class='{$stud_class}', stud_phone='{$stud_phone}', stud_image= '{$update_filename}' WHERE id='{$stud_id}'";

       $query_run = mysqli_query($con,$query);
      
         if($query_run){

            if($_FILES['stud_image']['name'] !='')
            {
             move_uploaded_file($_FILES["stud_image"]["tmp_name"], "upload/".$_FILES["stud_image"]["name"]);
               unlink('upload/'.$stud_image_old);
            }
           
            echo json_encode(array('message' => '<h6> Record Updated Successfully</h6>', 'status' => true ));
         //   $_SESSION['status'] = 'Data Updated Successfully';
        //    header('location:index.php');
         }
          else{
            echo json_encode(array('message' => '<h6> Record Not Updated</h6>', 'status' => false));
         //   $_SESSION['status'] = 'Data Not Updated';
        //    header('location:index.php');
          }
 


                         // End Update Code

?>