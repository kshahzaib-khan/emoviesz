
      <?php
        
          $con = mysqli_connect('localhost','root','','phpmysqlicrud');
          $query = 'SELECT * FROM phpimgcrud  ';
           $query_run = mysqli_query($con,$query);

           $output = "";
           if(mysqli_num_rows($query_run) > 0){
           $output ='
           
           <table class="table table-striped table-bordered" style="width:100%">
           <thead>

           <tr>
  
              <th>ID</th>
              <th>Student Name</th>
              <th>Student Class</th>
              <th>Student Phone</th>
              <th>Student Image</th>
              <th>Edit</th>
              <th>Delete</th>

                     </thead>';
                     
                     
         
                   while($row = mysqli_fetch_assoc($query_run)){
                    $id=$row['id'];
                    $stud_name=$row['stud_name'];
                    $stud_class=$row['stud_class']; 
                    $stud_phone=$row['stud_phone']; 
                    $stud_image=$row['stud_image'];
                         $output .= "<body>
                         
                                <tr>
                                                                  
             
                              
                             <td class='stud_id'>{$row["id"]}</td>
                             <td>{$row["stud_name"]}</td>
                             <td>{$row["stud_class"]}</td>
                             <td>{$row["stud_phone"]}</td>
                             
                             <td><img src='upload/$stud_image'width='50px'height='50px'></td>
                             <td><button class=' btn btn-success btn-sm edit-btn' value='{$row["id"]}'data-toggle='modal'data-target='#UpdateModal'>Edit</button></td>
                            
                             <td>
                             
                                  
                                  
                                    
                                    
              
                                    <input type='submit' data-id='{$row["id"]}'id='delete-image' class='btn btn-danger btn-sm'value='Delete'>
                                  
                                </td>
                              </tr>
                              
                                 </body>";
                                    
                                         
                                         
                   }
                  
                  
                   $output.='</table>';
                 
         
                   echo $output;
                     

                }

                else{
                         echo "<h2> NO Record Found</h2>";
                   }

?>
          

        
                
                